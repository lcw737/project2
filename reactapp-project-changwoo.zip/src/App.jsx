// src/App.jsx
import TopNavi from "./components/layouts/TopNavi";
import { Routes, Route } from "react-router-dom";

import Home         from "./Home";
import Login        from "./components/members/Login";
import Regist       from "./components/members/Regist";
import EditProfile  from "./components/members/EditProfile";

import BoardList    from "./components/boards/BoardList";
import BoardView    from "./components/boards/BoardView";
import BoardWrite   from "./components/boards/BoardWrite";

function App() {
  return (
    <>
      <TopNavi />
      <Routes>
        {/* 메인 */}
        <Route path="/" element={<Home />} />

        {/* 회원 */}
        <Route path="/signup"       element={<Regist />} />
        <Route path="/login"        element={<Login />} />
        <Route path="/edit-profile" element={<EditProfile />} />

        {/* 자유게시판 */}
        <Route path="/board1"             element={<BoardList boardType="free" />} />
        <Route path="/board1/view/:id"    element={<BoardView boardType="free" />} />
        <Route path="/board1/write"       element={<BoardWrite boardType="free" />} />

        {/* Q&A */}
        <Route path="/board2"             element={<BoardList boardType="qna" />} />
        <Route path="/board2/view/:id"    element={<BoardView boardType="qna" />} />
        <Route path="/board2/write"       element={<BoardWrite boardType="qna" />} />

        {/* 자료실 */}
        <Route path="/board3"             element={<BoardList boardType="dataroom" />} />
        <Route path="/board3/view/:id"    element={<BoardView boardType="dataroom" />} />
        <Route path="/board3/write"       element={<BoardWrite boardType="dataroom" />} />
      </Routes>
    </>
  );
}

export default App;
