// src/components/boards/BoardView.jsx
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { firestore } from "../../firebaseConfig";
import { doc, getDoc } from "firebase/firestore";

export default function BoardView({ boardType }) {
  const { id } = useParams();
  const [post, setPost] = useState(null);

  const collectionName =
    boardType === "free"
      ? "free_posts"
      : boardType === "qna"
      ? "qna_posts"
      : "dataroom_posts";

  useEffect(() => {
    async function fetchData() {
      const docRef = doc(firestore, collectionName, id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) setPost({ id: docSnap.id, ...docSnap.data() });
      else setPost(null);
    }
    fetchData();
  }, [id, boardType]);

  function formatDateTime(dt) {
    if (!dt) return "";
    const date = new Date(dt);
    const now = new Date();
    return date.toDateString() === now.toDateString()
      ? date.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })
      : date.toLocaleDateString("ko-KR");
  }

  if (!post) return <div style={{ padding: 50, textAlign: "center" }}>글을 찾을 수 없습니다.</div>;

  return (
    <main style={{
      maxWidth: 700, margin: "48px auto", background: "#fff", borderRadius: 16,
      boxShadow: "0 2px 16px rgba(80,80,130,0.10)", padding: "36px 38px"
    }}>
      <h2 style={{ fontSize: 26, fontWeight: 700, color: "#2563eb", marginBottom: 12 }}>{post.title}</h2>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20, color: "#3b3b55" }}>
        <div>
          <span style={{ fontWeight: 500 }}>{post.author}</span>
          <span style={{ marginLeft: 16, color: "#8585a5", fontSize: 14 }}>{formatDateTime(post.createdAt)}</span>
        </div>
        <Link to={`/${boardType === "free" ? "board1" : boardType === "qna" ? "board2" : "board3"}`} style={{ color: "#2563eb", textDecoration: "none", fontWeight: 500 }}>
          목록으로
        </Link>
      </div>
      <div style={{
        minHeight: 180, padding: "26px 18px", fontSize: 17,
        background: "#f7faff", borderRadius: 8, color: "#212343", marginBottom: 30,
      }}>
        {post.content}
      </div>
    </main>
  );
}
