// src/components/boards/BoardList.jsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { firestore } from "../../firebaseConfig";
import { collection, getDocs, query, orderBy } from "firebase/firestore";

export default function BoardList({ boardType }) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  // 게시판별 컬렉션명
  const collectionName =
    boardType === "free"
      ? "free_posts"
      : boardType === "qna"
      ? "qna_posts"
      : "dataroom_posts";

 useEffect(() => {
    let canceled = false;
    async function fetchData() {
      setLoading(true);
      try {
        const q    = query(
          collection(firestore, collectionName),
          orderBy("createdAt", "desc")
        );
        const snap = await getDocs(q);
        if (!canceled) {
          setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        }
      } catch (e) {
        console.error("Firestore fetch error:", e);
      } finally {
        if (!canceled) setLoading(false);
      }
    }
    fetchData();
    return () => { canceled = true; };
  }, [collectionName]);

  // 게시판명
  const BOARD_TITLE = {
    free: "자유게시판",
    qna: "Q&A 게시판",
    dataroom: "자료실"
  };

  // 날짜 포맷
  function formatDateTime(dt) {
    if (!dt) return "";
    const date = new Date(dt);
    const now = new Date();
    return date.toDateString() === now.toDateString()
      ? date.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })
      : date.toLocaleDateString("ko-KR");
  }

  return (
    <main style={{
      maxWidth: 800, margin: "48px auto", background: "#fff",
      borderRadius: 16, boxShadow: "0 2px 16px rgba(80,80,130,0.10)", padding: "36px 38px"
    }}>
      <h2 style={{
        fontSize: 28, fontWeight: 700, color: "#2563eb",
        marginBottom: 24, letterSpacing: "-0.5px"
      }}>
        {BOARD_TITLE[boardType]}
      </h2>
      <div style={{ textAlign: "right", marginBottom: 16 }}>
        <Link
          to={`/${boardType === "free" ? "board1" : boardType === "qna" ? "board2" : "board3"}/write`}
          style={{
            background: "#2563eb",
            color: "#fff",
            borderRadius: 6,
            padding: "9px 22px",
            textDecoration: "none",
            fontWeight: 500,
            boxShadow: "0 2px 8px #2563eb11",
            transition: "background 0.18s"
          }}
        >
          {boardType === "qna" ? "질문 등록" : boardType === "dataroom" ? "자료 등록" : "글쓰기"}
        </Link>
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse", background: "#fcfcfd" }}>
        <thead>
          <tr style={{ background: "#f3f6fb" }}>
            <th style={{ padding: "14px" }}>번호</th>
            <th style={{ padding: "14px" }}>제목</th>
            {boardType === "dataroom" && <th style={{ padding: "14px" }}>파일</th>}
            <th style={{ padding: "14px" }}>작성자</th>
            <th style={{ padding: "14px" }}>작성일시</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr>
              <td colSpan={boardType === "dataroom" ? 5 : 4} style={{ textAlign: "center", padding: 40 }}>불러오는 중...</td>
            </tr>
          ) : posts.length === 0 ? (
            <tr>
              <td colSpan={boardType === "dataroom" ? 5 : 4} style={{ textAlign: "center", padding: 40, color: "#aaa" }}>게시글이 없습니다.</td>
            </tr>
          ) : (
            posts.map((item, idx) => (
              <tr key={item.id} style={{ borderBottom: "1px solid #ececec" }}>
                <td style={{ padding: 14, textAlign: "center", color: "#666" }}>{posts.length - idx}</td>
                <td style={{ padding: 14 }}>
                  <Link
                    to={`/${boardType === "free" ? "board1" : boardType === "qna" ? "board2" : "board3"}/view/${item.id}`}
                    style={{ color: "#2563eb", textDecoration: "none", fontWeight: 500 }}
                  >
                    {item.title}
                  </Link>
                </td>
                {boardType === "dataroom" && (
                  <td style={{ padding: 14, textAlign: "center" }}>
                    <span>첨부파일</span>
                  </td>
                )}
                <td style={{ padding: 14, textAlign: "center", color: "#444" }}>{item.author}</td>
                <td style={{ padding: 14, textAlign: "center", color: "#444" }}>{formatDateTime(item.createdAt)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </main>
  );
}
