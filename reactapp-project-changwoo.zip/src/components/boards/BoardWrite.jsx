// src/components/boards/BoardWrite.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { firestore } from "../../firebaseConfig";
import { collection, addDoc } from "firebase/firestore";

export default function BoardWrite({ boardType }) {
  const [form, setForm] = useState({ title: "", content: "", author: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const collectionName =
    boardType === "free"
      ? "free_posts"
      : boardType === "qna"
      ? "qna_posts"
      : "dataroom_posts";

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.content || !form.author) {
      setError("모든 항목을 입력하세요.");
      return;
    }
    try {
      await addDoc(collection(firestore, collectionName), {
        ...form,
        createdAt: new Date().toISOString(),
      });
      alert("글 등록 완료!");
      navigate(`/${boardType === "free" ? "board1" : boardType === "qna" ? "board2" : "board3"}`);
    } catch (err) {
      alert("저장 실패!");
    }
  };

  return (
    <main style={{
      maxWidth: 600, margin: "56px auto", background: "#fff",
      borderRadius: 16, boxShadow: "0 2px 16px rgba(80,80,130,0.10)", padding: "36px 38px"
    }}>
      <h2 style={{ fontSize: 25, fontWeight: 700, color: "#2563eb", marginBottom: 28 }}>
        {boardType === "qna" ? "질문 등록" : boardType === "dataroom" ? "자료 등록" : "글쓰기"}
      </h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 20 }}>
          <input name="title" value={form.title} onChange={handleChange} placeholder="제목" style={{ width: "100%", padding: "13px 15px", fontSize: 17, borderRadius: 7, border: "1.5px solid #ccd6f6", outline: "none", marginBottom: 12, background: "#f8fafd" }} />
        </div>
        <div style={{ marginBottom: 20 }}>
          <textarea name="content" value={form.content} onChange={handleChange} placeholder="본문 내용을 입력하세요" rows={10} style={{ width: "100%", padding: "13px 15px", fontSize: 16, borderRadius: 7, border: "1.5px solid #ccd6f6", background: "#f8fafd", resize: "vertical" }} />
        </div>
        <div style={{ marginBottom: 20 }}>
          <input name="author" value={form.author} onChange={handleChange} placeholder="작성자" style={{ width: "100%", padding: "13px 15px", fontSize: 17, borderRadius: 7, border: "1.5px solid #ccd6f6", outline: "none", marginBottom: 12, background: "#f8fafd" }} />
        </div>
        {error && <div style={{ color: "#f04c50", marginBottom: 18, fontWeight: 500 }}>{error}</div>}
        <div style={{ textAlign: "right" }}>
          <button type="submit" style={{ background: "#2563eb", color: "#fff", border: "none", borderRadius: 7, padding: "12px 34px", fontSize: 17, fontWeight: 600, cursor: "pointer", boxShadow: "0 1px 8px #2563eb11" }}>등록</button>
        </div>
      </form>
    </main>
  );
}
