// src/components/layouts/TopNavi.jsx
import { Link, useLocation } from "react-router-dom";

const TopNavi = () => {
  const location = useLocation();

  // 현재 경로에 따라 강조(선택됨) 스타일 적용
  const navs = [
    { to: "/login", label: "로그인" },
    { to: "/signup", label: "회원가입" },
    { to: "/board1", label: "자유게시판" },
    { to: "/board2", label: "Q&A" },
    { to: "/board3", label: "자료실" },
  ];

  const navStyle = {
    background: "#212b36",
    padding: "0 32px",
    color: "#fff",
    display: "flex",
    alignItems: "center",
    height: 56,
    borderBottom: "1.5px solid #e2e8f0",
    boxShadow: "0 1px 6px 0 rgba(24,32,64,0.06)"
  };
  const logoStyle = {
    fontWeight: 700, fontSize: 21, letterSpacing: "-0.5px",
    marginRight: 44, color: "#fff", textDecoration: "none"
  };
  const navLinkStyle = (isActive) => ({
    color: isActive ? "#2d6af0" : "#fff",
    background: isActive ? "#fff" : "transparent",
    padding: "7px 19px",
    borderRadius: 5,
    marginRight: 3,
    textDecoration: "none",
    fontWeight: isActive ? 700 : 500,
    fontSize: 16,
    transition: "all 0.13s"
  });

  return (
    <nav style={navStyle}>
      <Link to="/" style={logoStyle}>MyCommunity</Link>
      <div style={{ display: "flex", gap: 2 }}>
        {navs.map(({ to, label }) => (
          <Link
            key={to}
            to={to}
            style={navLinkStyle(location.pathname.startsWith(to))}
          >
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default TopNavi;
