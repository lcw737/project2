import { useState, useEffect } from "react";
import { FaUser, FaLock } from "react-icons/fa";

export default function Login() {
  const [form, setForm] = useState({ userId: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loggedIn, setLoggedIn] = useState(false);

  // 마운트 시 로그인상태 체크
  useEffect(() => {
    if (localStorage.getItem("userId")) setLoggedIn(true);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let newErrors = {};
    if (!form.userId) newErrors.userId = "아이디를 입력하세요";
    if (!form.password) newErrors.password = "비밀번호를 입력하세요";
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    // 실제 인증은 생략(테스트용)
    localStorage.setItem("userId", form.userId);
    setLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.removeItem("userId");
    setLoggedIn(false);
    setForm({ userId: "", password: "" });
  };

  // 스타일: (질문에서 준 것 반영)
  const outer = {
    minHeight: "100vh",
    background: "#f4f6fa",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  };
  const container = {
    minWidth: "480px",    // ★ 0.5배 더 큼
    maxWidth: "520px",
    margin: "0 auto",
    background: "#fff",
    padding: "40px 38px 30px 38px",   // 패딩도 살짝 늘림
    borderRadius: "18px",
    boxShadow: "0 2px 16px 0 rgba(0,0,0,0.13)"
  };


  const title = {
    fontSize: 16,
    fontWeight: 800,
    marginBottom: 13,
    color: "#202d3e",
    letterSpacing: "-0.5px",
    textAlign: "center",
  };
  const group = { marginBottom: 10, textAlign: "left" };
  const label = { fontSize: 12, fontWeight: 600, marginBottom: 1, display: "flex", alignItems: "center", color: "#43627e" };
  const icon = { marginRight: 4, color: "#60e6a3", fontSize: 13 };
  const input = {
    width: "80%",            // 가로폭 (원하는 대로 조절)
    minWidth: "0",
    padding: "12px 14px",    // ← 여기서 '12px'가 위아래 padding!
    border: "1.2px solid #cfd8e3",
    borderRadius: "5px",
    background: "#f9fafc",
    fontSize: "16px",
    outlineColor: "#4361b0",
    display: "block",
    margin: "0 auto"
  };

  const button = {
    width: "100%",
    padding: "10px 0",
    background: "linear-gradient(90deg, #20395a 75%, #60e6a3 100%)",
    color: "#fff",
    border: "none",
    borderRadius: 7,
    fontWeight: 700,
    fontSize: 13,
    marginTop: 10,
    cursor: "pointer",
    boxShadow: "0 1px 6px rgba(44,62,94,0.04)",
    transition: "background 0.16s"
  };
  const error = { color: "#ec4c3d", fontSize: "10px", marginTop: "2px", minHeight: 11 };

  // 로그인 상태
  if (loggedIn) {
    const userId = localStorage.getItem("userId");
    return (
      <div style={outer}>
        <main style={container}>
          <div style={title}>로그인됨</div>
          <div style={{ textAlign: "center", margin: "16px 0 18px 0", fontWeight: 700, color: "#1b375a" }}>
            <FaUser style={icon} />
            <span>{userId} 님 환영합니다!</span>
          </div>
          <button onClick={handleLogout} style={button}>로그아웃</button>
        </main>
      </div>
    );
  }

  // 로그인 폼
  return (
    <div style={outer}>
      <main style={container}>
        <div style={title}>로그인</div>
        <form onSubmit={handleSubmit} autoComplete="off">
          <div style={group}>
            <label style={label}>
              <FaUser style={icon} /> 아이디
            </label>
            <input
              name="userId"
              value={form.userId}
              onChange={handleChange}
              style={input}
              autoFocus
              required
            />
            <div style={error}>{errors.userId}</div>
          </div>
          <div style={group}>
            <label style={label}>
              <FaLock style={icon} /> 비밀번호
            </label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              style={input}
              required
            />
            <div style={error}>{errors.password}</div>
          </div>
          <button type="submit" style={button}>로그인</button>
        </form>
      </main>
    </div>
  );
}
