// src/components/members/EditProfile.jsx
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { auth, firestore } from "../../firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, updateDoc } from "firebase/firestore";

export default function EditProfile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(undefined); // undefined=로딩중, null=로그아웃, object=로그인
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({
    userId:        "",
    name:          "",
    email:         "",
    emailDomain:   "",
    phone1:        "",
    phone2:        "",
    phone3:        "",
    zipCode:       "",
    address:       "",
    detailAddress: "",
  });

  const phone2Ref        = useRef();
  const phone3Ref        = useRef();
  const detailAddressRef = useRef();

  const [emailDomainType, setEmailDomainType] = useState("direct");
  const emailDomains = ["직접입력", "gmail.com", "naver.com", "daum.net"];

  // 1) DAUM 우편번호 API 로드 (최초 1회)
  useEffect(() => {
    if (!window.daum) {
      const s = document.createElement("script");
      s.src = "https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js";
      document.body.appendChild(s);
    }
  }, []);

  // 2) onAuthStateChanged: 인증 상태 구독
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return () => unsub();
  }, []);

  // 3) user가 로그인 완료되면 프로필 정보 불러오기
  useEffect(() => {
    if (user === undefined) return; // 인증 미확정
    if (!user) {
      alert("로그인이 필요합니다.");
      navigate("/login", { replace: true });
      return;
    }
    (async () => {
      setLoading(true);
      const ref  = doc(firestore, "users", user.uid);
      const snap = await getDoc(ref);
      const data = snap.exists() ? snap.data() : {};
      setForm({
        userId:        user.uid,
        name:          data.name          || "",
        email:         data.email         || "",
        emailDomain:   data.emailDomain   || "",
        phone1:        data.phone1        || "",
        phone2:        data.phone2        || "",
        phone3:        data.phone3        || "",
        zipCode:       data.zipCode       || "",
        address:       data.address       || "",
        detailAddress: data.detailAddress || "",
      });
      setEmailDomainType(data.emailDomain ? "select" : "direct");
      setLoading(false);
    })();
  }, [user, navigate]);

  // 4) 인증/프로필 로딩 중
  if (user === undefined || loading) {
    return <div style={{ textAlign: "center", marginTop: 40 }}>프로필을 불러오는 중…</div>;
  }

  // 5) 우편번호 찾기
  const handleOpenPostcode = () => {
    new window.daum.Postcode({
      oncomplete: ({ zonecode, address }) => {
        setForm(f => ({ ...f, zipCode: zonecode, address }));
        detailAddressRef.current?.focus();
      }
    }).open();
  };

  // 6) 입력 핸들러
  const handleChange = e => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
    setErrors(e => ({ ...e, [name]: "" }));
  };

  const handlePhoneChange = e => {
    const { name, value } = e.target;
    let v = value.replace(/\D/g, "");
    v = name === "phone1" ? v.slice(0,3) : v.slice(0,4);
    setForm(f => ({ ...f, [name]: v }));
    if (name === "phone1" && v.length===3) phone2Ref.current?.focus();
    if (name === "phone2" && v.length===4) phone3Ref.current?.focus();
  };

  const handleDomainSelect = e => {
    const val = e.target.value;
    if (val === "직접입력") {
      setEmailDomainType("direct");
      setForm(f => ({ ...f, emailDomain: "" }));
    } else {
      setEmailDomainType("select");
      setForm(f => ({ ...f, emailDomain: val }));
    }
  };

  // 7) 제출 핸들러
  const handleSubmit = async e => {
    e.preventDefault();
    const errs = {};
    if (!form.name)        errs.name = "이름을 입력하세요";
    if (!form.email)       errs.email = "이메일을 입력하세요";
    if (!form.emailDomain) errs.emailDomain = "이메일 도메인을 입력하세요";
    if (!form.phone1||!form.phone2||!form.phone3) errs.phone = "전화번호를 모두 입력하세요";
    if (!form.zipCode)     errs.zipCode = "우편번호를 입력하세요";
    if (!form.address)     errs.address = "기본주소를 입력하세요";
    if (!form.detailAddress) errs.detailAddress = "상세주소를 입력하세요";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setSubmitting(true);
    try {
      const ref = doc(firestore, "users", form.userId);
      await updateDoc(ref, form);
      alert("✅ 프로필이 수정되었습니다.");
      navigate("/");
    } catch {
      alert("⚠️ 저장 중 오류가 발생했습니다.");
    } finally {
      setSubmitting(false);
    }
  };

  // 8) 인라인 스타일
  const S = {
    container:  { maxWidth: 500, margin: "40px auto", background: "#fff", padding: 40, borderRadius: 8, boxShadow: "0 2px 8px rgba(0,0,0,0.1)" },
    group:      { marginBottom: 18 },
    label:      { display: "block", marginBottom: 5, fontWeight: "bold" },
    input:      { width: "100%", padding: 8, border: "1px solid #ccc", borderRadius: 4 },
    postWrap:   { display: "flex", gap: 8, alignItems: "center" },
    postButton: { padding: "8px 12px", background: "#2563eb", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer" },
    button:     { width: "100%", padding: "10px 0", fontSize: 17, fontWeight: 600, background: "#007bff", color: "#fff", border: "none", borderRadius: 4 }
  };

  return (
    <main style={S.container}>
      <h2 style={{ fontSize:22, marginBottom:25 }}>회원정보 수정</h2>
      <form onSubmit={handleSubmit} autoComplete="off">
        {/* 아이디 (읽기전용) */}
        <div style={S.group}>
          <label style={S.label}>아이디</label>
          <input name="userId" value={form.userId} style={{...S.input, background:"#f0f0f0"}} readOnly/>
        </div>
        {/* 이름 */}
        <div style={S.group}>
          <label style={S.label}>이름</label>
          <input name="name" value={form.name} onChange={handleChange} style={S.input}/>
          {errors.name && <div style={{color:"red"}}>{errors.name}</div>}
        </div>
        {/* 이메일 */}
        <div style={S.group}>
          <label style={S.label}>이메일</label>
          <div style={{ display: "flex", gap: 7 }}>
            <input name="email" value={form.email} onChange={handleChange} style={{ ...S.input, flex: 1 }}/>
            <span>@</span>
            <input name="emailDomain" value={form.emailDomain} onChange={handleChange}
                   style={{...S.input, width:120, background: emailDomainType==="select"?"#f3f3f3":"#fff"}}
                   readOnly={emailDomainType==="select"} />
            <select value={emailDomainType==="select"?form.emailDomain:"직접입력"}
                    onChange={handleDomainSelect} style={{ ...S.input, width:110 }}>
              <option value="">도메인 선택</option>
              {emailDomains.map(d=><option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          {(errors.email || errors.emailDomain) && <div style={{color:"red"}}>{errors.email || errors.emailDomain}</div>}
        </div>
        {/* 휴대전화 */}
        <div style={S.group}>
          <label style={S.label}>휴대전화번호</label>
          <div style={{ display: "flex", gap: 7 }}>
            <input name="phone1" value={form.phone1} onChange={handlePhoneChange} style={{ ...S.input, width:60 }}/>
            <span>-</span>
            <input ref={phone2Ref} name="phone2" value={form.phone2} onChange={handlePhoneChange} style={{ ...S.input, width:75 }}/>
            <span>-</span>
            <input ref={phone3Ref} name="phone3" value={form.phone3} onChange={handlePhoneChange} style={{ ...S.input, width:75 }}/>
          </div>
          {errors.phone && <div style={{color:"red"}}>{errors.phone}</div>}
        </div>
        {/* 주소 */}
        <div style={S.group}>
          <label style={S.label}>우편번호</label>
          <div style={S.postWrap}>
            <input name="zipCode" value={form.zipCode} readOnly style={{ ...S.input, width: 120 }} />
            <button type="button" onClick={handleOpenPostcode} style={S.postButton}>우편번호 찾기</button>
          </div>
          {errors.zipCode && <div style={{color:"red"}}>{errors.zipCode}</div>}
        </div>
        <div style={S.group}>
          <label style={S.label}>기본주소</label>
          <input name="address" value={form.address} readOnly onChange={handleChange} style={S.input}/>
          {errors.address && <div style={{color:"red"}}>{errors.address}</div>}
        </div>
        <div style={S.group}>
          <label style={S.label}>상세주소</label>
          <input ref={detailAddressRef} name="detailAddress" value={form.detailAddress} onChange={handleChange} style={S.input}/>
          {errors.detailAddress && <div style={{color:"red"}}>{errors.detailAddress}</div>}
        </div>
        <button type="submit" style={S.button} disabled={submitting}>
          {submitting ? "저장 중…" : "회원정보 수정"}
        </button>
      </form>
    </main>
  );
}
