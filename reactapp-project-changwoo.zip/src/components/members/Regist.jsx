import { useState, useRef } from "react";
import DaumPostcode from "react-daum-postcode";
import { auth, firestore } from "../../firebaseConfig";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

export default function Regist() {
  const [form, setForm] = useState({
    userId: "",
    password: "",
    passwordConfirm: "",
    name: "",
    email: "",
    emailDomain: "",
    phone1: "",
    phone2: "",
    phone3: "",
    zipCode: "",
    address: "",
    detailAddress: "",
  });
  const [showPostcode, setShowPostcode] = useState(false);
  const [emailDomainType, setEmailDomainType] = useState("select");
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const phone2Ref = useRef();
  const phone3Ref = useRef();
  const detailAddressRef = useRef();
  const emailDomains = ["gmail.com", "naver.com", "daum.net", "직접입력"];

  // 입력 핸들러
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: "" }));
  };

  // 휴대폰 자동 포커싱
  const handlePhoneChange = (e) => {
    const { name, value } = e.target;
    let newValue = value.replace(/\D/g, "");
    if (name === "phone1") newValue = newValue.slice(0, 3);
    if (name === "phone2" || name === "phone3") newValue = newValue.slice(0, 4);

    setForm(prev => ({ ...prev, [name]: newValue }));

    if (name === "phone1" && newValue.length === 3) phone2Ref.current.focus();
    if (name === "phone2" && newValue.length === 4) phone3Ref.current.focus();
  };

  // 이메일 도메인 선택
  const handleDomainSelect = (e) => {
    const value = e.target.value;
    setEmailDomainType(value === "직접입력" ? "direct" : "select");
    setForm(prev => ({ ...prev, emailDomain: value === "직접입력" ? "" : value }));
  };

  // 우편번호 찾기
  const completePostcode = (data) => {
    setForm(prev => ({
      ...prev,
      zipCode: data.zonecode,
      address: data.address,
    }));
    setShowPostcode(false);
    setTimeout(() => detailAddressRef.current?.focus(), 0);
  };

  // 제출: Auth 회원가입 & Firestore 저장
  const handleSubmit = async (e) => {
    e.preventDefault();
    let newErrors = {};

    if (!form.userId) newErrors.userId = "아이디(닉네임)를 입력하세요";
    if (!form.password) newErrors.password = "패스워드를 입력하세요";
    if (!form.passwordConfirm) newErrors.passwordConfirm = "패스워드 확인을 입력하세요";
    if (form.password !== form.passwordConfirm) newErrors.passwordConfirm = "패스워드가 일치하지 않습니다";
    if (!form.name) newErrors.name = "이름을 입력하세요";
    if (!form.email) newErrors.email = "이메일을 입력하세요";
    if (!form.emailDomain) newErrors.emailDomain = "이메일 도메인을 선택하거나 입력하세요";
    if (!form.phone1 || !form.phone2 || !form.phone3) newErrors.phone = "휴대전화번호를 입력하세요";
    if (!form.zipCode) newErrors.zipCode = "우편번호를 입력하세요";
    if (!form.address) newErrors.address = "기본주소를 입력하세요";
    if (!form.detailAddress) newErrors.detailAddress = "상세주소를 입력하세요";

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    setLoading(true);
    try {
      // 1) 이메일 계정 생성
      const emailFull = `${form.email}@${form.emailDomain}`;
      const userCredential = await createUserWithEmailAndPassword(auth, emailFull, form.password);
      const user = userCredential.user;

      // 2) Firestore에 로그인 uid 기준 저장
      await setDoc(doc(firestore, "users", user.uid), {
        uid: user.uid,
        userId: form.userId, // 닉네임 (별명)
        name: form.name,
        email: form.email,
        emailDomain: form.emailDomain,
        phone1: form.phone1,
        phone2: form.phone2,
        phone3: form.phone3,
        zipCode: form.zipCode,
        address: form.address,
        detailAddress: form.detailAddress,
        createdAt: new Date().toISOString(),
      });

      alert("회원가입 완료! 로그인 해주세요.");
      setForm({
        userId: "",
        password: "",
        passwordConfirm: "",
        name: "",
        email: "",
        emailDomain: "",
        phone1: "",
        phone2: "",
        phone3: "",
        zipCode: "",
        address: "",
        detailAddress: "",
      });
    } catch (err) {
      alert("회원가입 실패: " + err.message);
    }
    setLoading(false);
  };

  // 스타일 (동일)
  const containerStyle = {
    maxWidth: "500px",
    margin: "40px auto",
    backgroundColor: "#fff",
    padding: "40px",
    borderRadius: "8px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
  };
  const formGroup = { marginBottom: "18px" };
  const label = { display: "block", marginBottom: "5px", fontWeight: "bold" };
  const input = { width: "100%", padding: "8px", border: "1px solid #ccc", borderRadius: "4px" };
  const button = { padding: "8px 14px", backgroundColor: "#007bff", color: "#fff", border: "none", borderRadius: "4px", cursor: "pointer" };
  const errorMsg = { color: "red", fontSize: "13px", marginTop: "3px" };

  return (
    <main style={containerStyle}>
      <h2 style={{ fontSize: "22px", marginBottom: "25px" }}>회원가입</h2>
      <form onSubmit={handleSubmit} autoComplete="off">
        {/* 아이디(닉네임) */}
        <div style={formGroup}>
          <label style={label}>아이디(닉네임)</label>
          <input name="userId" value={form.userId} onChange={handleChange} style={input} autoFocus required />
          {errors.userId && <div style={errorMsg}>{errors.userId}</div>}
        </div>
        {/* 비밀번호 */}
        <div style={formGroup}>
          <label style={label}>비밀번호</label>
          <input type="password" name="password" value={form.password} onChange={handleChange} style={input} required />
          {errors.password && <div style={errorMsg}>{errors.password}</div>}
        </div>
        {/* 비밀번호 확인 */}
        <div style={formGroup}>
          <label style={label}>비밀번호 확인</label>
          <input type="password" name="passwordConfirm" value={form.passwordConfirm} onChange={handleChange} style={input} required />
          {errors.passwordConfirm && <div style={errorMsg}>{errors.passwordConfirm}</div>}
        </div>
        {/* 이름 */}
        <div style={formGroup}>
          <label style={label}>이름</label>
          <input name="name" value={form.name} onChange={handleChange} style={input} required />
          {errors.name && <div style={errorMsg}>{errors.name}</div>}
        </div>
        {/* 이메일 */}
        <div style={formGroup}>
          <label style={label}>이메일</label>
          <div style={{ display: "flex", gap: "7px" }}>
            <input name="email" value={form.email} onChange={handleChange} style={input} required />
            <span>@</span>
            <input
              name="emailDomain"
              value={form.emailDomain}
              onChange={handleChange}
              style={{
                ...input,
                width: "120px",
                backgroundColor: emailDomainType === "select" ? "#f3f3f3" : "white"
              }}
              readOnly={emailDomainType === "select"}
              required
            />
            <select onChange={handleDomainSelect} style={{ ...input, width: "110px" }} value={emailDomainType === "select" ? form.emailDomain : "직접입력"}>
              <option value="">도메인 선택</option>
              {emailDomains.map(domain => (
                <option key={domain} value={domain}>{domain}</option>
              ))}
            </select>
          </div>
          {(errors.email || errors.emailDomain) && <div style={errorMsg}>{errors.email || errors.emailDomain}</div>}
        </div>
        {/* 휴대전화 */}
        <div style={formGroup}>
          <label style={label}>휴대전화번호</label>
          <div style={{ display: "flex", gap: "7px" }}>
            <input name="phone1" maxLength={3} value={form.phone1} onChange={handlePhoneChange} style={{ ...input, width: "60px" }} required />-
            <input ref={phone2Ref} name="phone2" maxLength={4} value={form.phone2} onChange={handlePhoneChange} style={{ ...input, width: "75px" }} required />-
            <input ref={phone3Ref} name="phone3" maxLength={4} value={form.phone3} onChange={handlePhoneChange} style={{ ...input, width: "75px" }} required />
          </div>
          {errors.phone && <div style={errorMsg}>{errors.phone}</div>}
        </div>
        {/* 주소 */}
        <div style={formGroup}>
          <label style={label}>우편번호</label>
          <div style={{ display: "flex", gap: "10px" }}>
            <input name="zipCode" value={form.zipCode} style={{ ...input, width: "120px", backgroundColor: "#f3f3f3" }} readOnly required />
            <button type="button" style={button} onClick={() => setShowPostcode(true)}>우편번호 찾기</button>
          </div>
          {errors.zipCode && <div style={errorMsg}>{errors.zipCode}</div>}
        </div>
        <div style={formGroup}>
          <label style={label}>기본주소</label>
          <input name="address" value={form.address} style={{ ...input, backgroundColor: "#f3f3f3" }} readOnly required />
          {errors.address && <div style={errorMsg}>{errors.address}</div>}
        </div>
        <div style={formGroup}>
          <label style={label}>상세주소</label>
          <input ref={detailAddressRef} name="detailAddress" value={form.detailAddress} onChange={handleChange} style={input} required />
          {errors.detailAddress && <div style={errorMsg}>{errors.detailAddress}</div>}
        </div>
        <button type="submit" style={{ ...button, width: "100%", fontWeight: 600, fontSize: "17px" }} disabled={loading}>
          {loading ? "저장 중..." : "회원가입"}
        </button>
      </form>
      {showPostcode && (
        <div style={{ marginTop: "18px" }}>
          <DaumPostcode onComplete={completePostcode} autoClose />
        </div>
      )}
    </main>
  );
}
