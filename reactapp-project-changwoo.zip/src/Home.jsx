// src/Home.jsx
import { Link } from "react-router-dom";

export default function Home() {
  const boxStyle  = { maxWidth: 500, margin: "60px auto", padding: 32, background: "#fff", borderRadius: 12, boxShadow: "0 2px 14px rgba(40,60,120,0.09)", textAlign: "center" };
  const btn       = { display: "inline-block", margin: "12px 10px 0", padding: "10px 28px", background: "#2d6af0", color: "#fff", borderRadius: 6, fontSize: 17, textDecoration: "none", fontWeight: 600, transition: "background 0.2s" };
  const mainTitle = { fontSize: 30, fontWeight: 700, marginBottom: 16, color: "#2d3748" };
  const desc      = { color: "#444", fontSize: 17, marginBottom: 18 };

  return (
    <main style={boxStyle}>
      <div style={mainTitle}>MyCommunity에 오신걸 환영합니다 🎉</div>
      <div style={desc}>
        이 사이트는 회원가입/로그인, 자유게시판, Q&A, 자료실 기능을 제공합니다.<br />
        아래 메뉴로 바로 이동해보세요!
      </div>
      <div>
        <Link to="/signup"       style={btn}>회원가입</Link>
        <Link to="/login"        style={btn}>로그인</Link>
        <Link to="/board1"       style={btn}>자유게시판</Link>
        <Link to="/board2"       style={btn}>Q&A</Link>
        <Link to="/board3"       style={btn}>자료실</Link>
        <Link to="/edit-profile" style={btn}>회원정보 수정</Link>
      </div>
    </main>
  );
}
